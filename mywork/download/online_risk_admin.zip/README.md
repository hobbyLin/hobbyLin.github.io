# online_risk

> A Vue.js project

## Build Setup

``` bash
# 安装npm包
yarn

# 本地启开发服务
npm run dev

# 打生产环境的包
npm run build:prd

# 打测试环境的包
npm run build:stg

```
