<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>
<script>
export default {
    data() {
        return {
        };
    },
    created() {
    }
}
</script>
<style lang="scss">
    @import "./assets/styles/reset";
    @import "./assets/styles/variables";
</style>
