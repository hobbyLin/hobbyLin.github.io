<template>
    <div class="feed">
        feed
    </div>
</template>
<script>
export default {
    name: 'feed',
    data() {
        return {

        }
    },
}
</script>
<style lang="scss" scoped>
	@import "../../assets/styles/variables";
</style>
